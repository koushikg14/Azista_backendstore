# NorthwindNode

This example project accompanies the _Learn the Mean Stack- Beginner Tutorial_. The learning material can be found at:

[http://www.bradoncode.com/tutorials/learn-mean-stack-tutorial/](http://www.bradoncode.com/tutorials/learn-mean-stack-tutorial/)


## Populating Test Data

You can make use of data migrations to load some test data.

The NPM package _migrate_ is a dev dependency. Once that is installed, ensure that that app is running, create a user account with the details:

* username: admin
* password: password

Then run:

$ migrate up
